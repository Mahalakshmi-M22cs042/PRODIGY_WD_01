const navbar = document.getElementById("navbar");
const progressBar = document.getElementById("progress-bar");

window.addEventListener("scroll", () => {

    if(window.scrollY > 50){
        navbar.classList.add("scrolled");
    }
    else{
        navbar.classList.remove("scrolled");
    }

    let scrollPercentage =
        (window.scrollY /
        (document.documentElement.scrollHeight -
        window.innerHeight)) * 100;

    progressBar.style.width =
        scrollPercentage + "%";
});